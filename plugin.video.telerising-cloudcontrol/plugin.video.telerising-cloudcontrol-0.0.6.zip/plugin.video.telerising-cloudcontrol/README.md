# plugin.video.telerising-cloudcontrol
Kodi Addon to manage Cloud Recordings via Telerising API. Get Access to Zattoo VOD Service
