# service.telerising
Kodi Addon for advanced access to Zattoo &amp; Reseller internet streams, see https://github.com/sunsettrack4/telerising
